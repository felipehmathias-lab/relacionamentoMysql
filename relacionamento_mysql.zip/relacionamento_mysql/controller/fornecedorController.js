import { Fornecedor } from "../model/fornecedor.js"
import { cadastrar, listar, deletar, atualizar, buscarPorId } from "../repository/fornecedorRepository.js"

export async function cadastrarFornecedor(req, res){
    try{
    const {nome, cnpj} = req.body; 
    
    if(!nome === undefined || cnpj === undefined) {
        return res.status(400).json({mensagem: "Nome e cnpj são obrigatórios"})
    };

    const fornecedor = new Fornecedor(nome, cnpj);

    cadastrar(fornecedor);

    res.status(201).json(fornecedor);

    } catch (erro){
        return res.status(500).json({mensagem: "Erro ao cadastrar o fornecedor"})
    }
}

export async function listarFornecedor(req, res) {
    try{
    const fornecedores = await listar();

    res.status(200).json(fornecedores);
    } catch (erro){
        return res.status(500).json({mensagem: "Erro ao listar os fornecedores"})
    }
}

export async function buscarFornecedorPorId(req, res) {
    try{
    const id = Number(req.params.indice);

    const fornecedor = await buscarPorId(id);

    if (!fornecedor) {
        return res.status(404).json({
            mensagem: "Fornecedor não encontrado"
        });
    }

    res.status(200).json(fornecedor);
    } catch (erro){
    return res.status(500).json({mensagem: "Erro ao buscar por ID"});
    }
}

export async function atualizarFornecedor(req, res) {
    try{
    const id = Number(req.params.indice);

    const fornecedor = await buscarPorIndice(id);

    if (!fornecedor) {
        return res.status(404).json({
            mensagem: "Fornecedor não encontrado"
        });
    }

    const { nome, cnpj } = req.body;

    if (nome !== undefined) {
        fornecedor.nome = nome;
    }

    if (cnpj !== undefined) {
        fornecedor.cnpj = cnpj;
    }

    const resultado = await atualizar(id, fornecedor);

    if(resultado<=0){
        return res.status(400).json(
            {mensagem: "Nenhuma informação atualizada no banco de dados"}
        )
    }
    res.status(200).json(fornecedor);
    } catch (erro) {
    return res.status(500).json({mensagem: "Erro ao buscar fornecedor por ID"});
    }
}

export async function deletarFornecedor(req, res) {
    try {
    const id = Number(req.params.id)

    const indice = Number(req.params.indice);

    const fornecedor = await buscarPorId(id);

    if (!fornecedor) {
        return res.status(404).json({
            mensagem: "Fornecedor não encontrado"
        });
    }

    const resultado = await deletar(indice);

    if(resultado<=0){
        return res.status(400).json({mensagem: "Nenhum fornecedor foi deletado do banco de dados"})
    }

    deletar(indice);

    res.status(200).json({
        mensagem: "Fornecedor deletado com sucesso"
    });
    } catch (erro) {
        return res.status(500).json({mensagem: "Erro ao deletar fornecedor"});
    }
}