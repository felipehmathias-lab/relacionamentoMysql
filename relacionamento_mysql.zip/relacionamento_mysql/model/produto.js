export class Produto{
    constructor(descricao, preco, peso){
        this.descricao = descricao,
        this.preco = preco,
        this.peso = peso;
    }

    validar() {
        if (!this.descricao || this.descricao.trim().length < 3) {
            throw new Error("Descrição deve ter pelo menos 3 caracteres");
        }

        if (Number(this.preco) <= 0) {
            throw new Error("Preço deve ser maior que zero");
        }

        if (!this.cnpj || this.cnpj.trim().length !== 14){
            throw new Error("CNPJ deve conter 14 caracteres");
        }
    }

    static validarId(id) {
        if (!Number.isInteger(id) || id <= 0) {
            throw new Error("ID de fornecedor debe ser um número natural");
        }
    }
}