import conexao from "../database/conexao.js";

export async function buscarPorId(id) {
  const sql = "SELECT * FROM produto WHERE id_produto = ?";
  const [produtos] = await conexao.execute(sql, [id]);

  return produtos[0];
}

export async function vincularFornecedor(idProduto, idFornecedor) {
  const sql = "UPDATE produto SET fk_id_produto = ? WHERE id_produto = ?";

  const [resultado] = await conexao.execute(sql, [
    idFornecedor,
    idProduto
  ]);

  return resultado.affectedRows;
}

export async function removerFornecedor(idProduto) {
  const sql = "UPDATE produto SET fk_id_produto = NULL WHERE id_produto = ?";

  const [resultado] = await conexao.execute(sql, [idProduto]);

  return resultado.affectedRows;
}

export async function cadastrar(produto) {
    const sql = 'INSERT INTO produto (nome, cnpj) VALUES (?, ?, ?)'

    const [resultado] = await conexao.execute(
        sql, [produto.descricao, produto.preco, produto.peso]
    );

    return resultado.insertId;
}

export async function listar() {
    const sql = 'SELECT * FROM produtos ORDER BY id_produto';

    const [resultado] = await conexao.execute(sql);

    return resultado;
}

export async function buscarPorID(id) {
    const sql = 'SELECT * FROM produtos WHERE id_produto = ?';

    const [resultado] = await conexao.execute(sql, [id]);

    return resultado[0];
}

export async function atualizar(id, produto) {
    const sql = 'UPDATE produtos SET descricao = ?, preco = ?, peso = ? WHERE id_produto = ?';

    const [resultado] = await conexao.execute(
        sql,[
            produto.descricao,
            produto.preco,
            produto.peso,
            id
        ]
    );

    return resultado.affectedRows
}

export async function deletar(id) {
    const sql = 'DELETE FROM produtos WHERE id_produto = ?'

    const [resultado] = await conexao.execute(sql, id);

    return resultado.affectedRows;
}