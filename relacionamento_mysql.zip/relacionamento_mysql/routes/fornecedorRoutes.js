import express from "express"

import { cadastrarFornecedor,
    listarFornecedor,
    atualizarFornecedor,
    deletarFornecedor,
    buscarFornecedorPorId
} from "../controller/fornecedorController.js";

const router = express.Router();

router.post("/", cadastrarFornecedor);
router.get("/", listarFornecedor);
router.get("/:indice", buscarFornecedorPorId);
router.patch("/:indice", atualizarFornecedor);
router.delete("/:indice", deletarFornecedor);

export default router;