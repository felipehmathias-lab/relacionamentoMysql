import { Router } from "express";
import {
  vincularFornecedorAoProduto,
  removerFornecedorDoProduto
} from "../controller/produtoController.js";

import { cadastrarProduto,
    listarFornecedor,
    atualizarFornecedor,
    deletarFornecedor,
    buscarFornecedorPorId
} from "../controller/fornecedorController.js";

const router = Router();

router.patch(
  "/:idProduto/vincular-fornecedor/:idFornecedor",
  vincularFornecedorAoProduto
);

router.patch(
  "/:idProduto/remover-fornecedor",
  removerFornecedorDoProduto
);


router.post("/", cadastrarProduto);
router.get("/", listarFornecedor);
router.get("/:indice", buscarFornecedorPorId);
router.patch("/:indice", atualizarFornecedor);
router.delete("/:indice", deletarFornecedor);


export default router;